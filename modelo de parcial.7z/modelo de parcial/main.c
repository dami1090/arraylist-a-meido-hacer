#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"
//https://www.mockaroo.com/
//http://www.utnfravirtual.org.ar/pluginfile.php/41991/mod_page/content/13/Parcial_2_Lab_I_A2015_C1.pdf

int main()
{

    printf("Hello world!\n");
    return 0;
}
