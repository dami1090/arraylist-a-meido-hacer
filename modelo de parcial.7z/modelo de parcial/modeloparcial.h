#include <stdio.h>
#include <stdlib.h>
#include "ArrayList.h"

struct typedef{
 int codigoProducto;
 char* descrip;// cadena string dinamico,lo guardo en un buffer y dsp le hago un len y lo genero cn un malloc;
 float importe;
 int cantidad;
 int activo;
 }eProducto;





